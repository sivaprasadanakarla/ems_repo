package com.citi.employee.model;

public class ChildDetails {
private String childName;
private int childAge;
private String chaildGender;
public String getChildName() {
	return childName;
}
public void setChildName(String childName) {
	this.childName = childName;
}
public int getChildAge() {
	return childAge;
}
public void setChildAge(int childAge) {
	this.childAge = childAge;
}
public String getChaildGender() {
	return chaildGender;
}
public void setChaildGender(String chaildGender) {
	this.chaildGender = chaildGender;
}

}
