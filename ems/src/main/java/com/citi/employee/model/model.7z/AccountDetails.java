package com.citi.employee.model;

public class AccountDetails {
private String salAccountNumber;
private String salaryBankName;
private String salaryIfscCode;
private String reimbursementBankName;
private String reimbursementIfscCode;
public String getSalAccountNumber() {
	return salAccountNumber;
}
public void setSalAccountNumber(String salAccountNumber) {
	this.salAccountNumber = salAccountNumber;
}
public String getSalaryBankName() {
	return salaryBankName;
}
public void setSalaryBankName(String salaryBankName) {
	this.salaryBankName = salaryBankName;
}
public String getSalaryIfscCode() {
	return salaryIfscCode;
}
public void setSalaryIfscCode(String salaryIfscCode) {
	this.salaryIfscCode = salaryIfscCode;
}
public String getReimbursementBankName() {
	return reimbursementBankName;
}
public void setReimbursementBankName(String reimbursementBankName) {
	this.reimbursementBankName = reimbursementBankName;
}
public String getReimbursementIfscCode() {
	return reimbursementIfscCode;
}
public void setReimbursementIfscCode(String reimbursementIfscCode) {
	this.reimbursementIfscCode = reimbursementIfscCode;
}

}
