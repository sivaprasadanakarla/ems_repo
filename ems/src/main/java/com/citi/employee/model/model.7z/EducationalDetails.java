package com.citi.employee.model;

import java.util.Date;

public class EducationalDetails {
	private String highestdegreeId;
	private Date yearOfPassout;
	private String secondhighestQualification;
	private Date yearOfPassoutSecondHiQual;
	private Date sscPassoutyear;
	public String getHighestdegreeId() {
		return highestdegreeId;
	}
	public void setHighestdegreeId(String highestdegreeId) {
		this.highestdegreeId = highestdegreeId;
	}
	public Date getYearOfPassout() {
		return yearOfPassout;
	}
	public void setYearOfPassout(Date yearOfPassout) {
		this.yearOfPassout = yearOfPassout;
	}
	public String getSecondhighestQualification() {
		return secondhighestQualification;
	}
	public void setSecondhighestQualification(String secondhighestQualification) {
		this.secondhighestQualification = secondhighestQualification;
	}
	public Date getYearOfPassoutSecondHiQual() {
		return yearOfPassoutSecondHiQual;
	}
	public void setYearOfPassoutSecondHiQual(Date yearOfPassoutSecondHiQual) {
		this.yearOfPassoutSecondHiQual = yearOfPassoutSecondHiQual;
	}
	public Date getSscPassoutyear() {
		return sscPassoutyear;
	}
	public void setSscPassoutyear(Date sscPassoutyear) {
		this.sscPassoutyear = sscPassoutyear;
	}

}
