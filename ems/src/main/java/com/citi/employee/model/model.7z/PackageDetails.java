package com.citi.employee.model;

public class PackageDetails {
	private String costToEconomy;
	private int basicSalary;
	private int houseRentAllowance;
	private int specialAllowance;
	public String getCostToEconomy() {
		return costToEconomy;
	}
	public void setCostToEconomy(String costToEconomy) {
		this.costToEconomy = costToEconomy;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getHouseRentAllowance() {
		return houseRentAllowance;
	}
	public void setHouseRentAllowance(int houseRentAllowance) {
		this.houseRentAllowance = houseRentAllowance;
	}
	public int getSpecialAllowance() {
		return specialAllowance;
	}
	public void setSpecialAllowance(int specialAllowance) {
		this.specialAllowance = specialAllowance;
	}

}
