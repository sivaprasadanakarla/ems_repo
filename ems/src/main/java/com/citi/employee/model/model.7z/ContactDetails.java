package com.citi.employee.model;

public class ContactDetails {
	private Phone phone;
	private Email email;
	public Phone getPhone() {
		return phone;
	}
	public void setPhone(Phone phone) {
		this.phone = phone;
	}
	public Email getEmail() {
		return email;
	}
	public void setEmail(Email email) {
		this.email = email;
	}
	
		

}
